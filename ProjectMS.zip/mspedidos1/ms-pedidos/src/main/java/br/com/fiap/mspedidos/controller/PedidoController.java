package br.com.fiap.mspedidos.controller;

        import br.com.fiap.mspedidos.dto.PedidoDTO;
        import br.com.fiap.mspedidos.dto.StatusDTO;
        import br.com.fiap.mspedidos.service.PedidoService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.ResponseEntity;
        import org.springframework.web.bind.annotation.*;
        import org.springframework.web.util.UriComponentsBuilder;

        import javax.validation.Valid;
        import javax.validation.constraints.NotNull;
        import java.net.URI;
        import java.util.List;
        import java.util.Stack;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService service;

    @GetMapping
    public ResponseEntity< List<PedidoDTO>> findAll() {
        List<PedidoDTO> dto = service.findAll();
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PedidoDTO> findById(@PathVariable @NotNull Long id){
        PedidoDTO dto = service.findById(id);
        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<PedidoDTO> insert(@RequestBody @Valid PedidoDTO dto, UriComponentsBuilder uriBuilder) {
        dto = service.insert(dto);
        URI uri = uriBuilder.path("/pedidos/{id}").buildAndExpand((dto.getId())).toUri();
        return ResponseEntity.created(uri).body(dto);
    }

    @PutMapping("/{id}/pago")
    public ResponseEntity<Void> aprovarPagamentoPedido(@PathVariable @NotNull Long id) {
        service.aprovarPagamentoPedido(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<PedidoDTO> updateStatus(@PathVariable Long id, @RequestBody StatusDTO statusDTO){
        PedidoDTO dto = service.updateStatus(id, statusDTO);
        return ResponseEntity.ok(dto);
    }
}