package br.com.fiap.mspedidos.dto;

import br.com.fiap.mspedidos.model.Status;

public class StatusDTO {

    private Status status;

    public Status getStatus() {
        return status;
    }
}
